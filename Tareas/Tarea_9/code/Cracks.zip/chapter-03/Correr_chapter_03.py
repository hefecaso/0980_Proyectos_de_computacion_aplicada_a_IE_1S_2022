from os import system
import os

os.system ("clear")
system("python3 load_display_save.py --image trex.png")

