from os import system
import os

os.system ("clear")
system("python3 getting_and_setting.py --image trex.png")
