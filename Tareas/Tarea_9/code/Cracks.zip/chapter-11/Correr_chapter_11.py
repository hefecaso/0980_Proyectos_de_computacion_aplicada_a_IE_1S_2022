from os import system
import os

os.system ("clear")
system("python3 counting_coins.py --image coins.png")
